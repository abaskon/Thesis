------- Forwarded Message --------
Subject:
Wavelet Python Software
Date: Wed, 24 Dec 2014 00:54:00 +0300
From: Evgeniya Predybaylo <predybaylo.evgenia<AT>gmail.com>
To: chris<AT>rsinc.com, compo<AT>colorado.edu
CC: Georgiy Stenchikov <georgiy.stenchikov<AT>kaust.edu.sa>

Dear Dr. Torrence and Dr. Compo,

my name is Evgeniya and I am a PhD Student under the supevision of Prof. Georgiy Stenchikov at King Abdullah University of Science and Technology (KAUST).

I am writing to say a great thank you for the wavelet paper and software you have provided on the website (http://paos.colorado.edu/research/wavelets/). I have found them very useful for my research! However, as I am mostly using Python, I have rewritten the code for Python environment. I have attached two Python files that contain all needed functions and the example, exactly as you have it for the other environments. I hope they can be somehow useful. Please let me know if you encounter any troubles running these codes.

Thank you for your time and attention!

Sincerely,

Evgeniya Predybaylo

--
PhD Student, Earth Sciences and Engineering Program
Chair of Graduate Student Council
King Abdullah University of Science and Technology
