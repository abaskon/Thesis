# Torrence &amp; Compo Wavelet Analysis Software

*Note*: This folder contains the old Interactive Wavelet Plot software.
We had to remove the old Interactive Wavelet site for security reasons.
It relied on IDL's ION software package which is now defunct.
This will not produce wavelet plots. Do not use.
